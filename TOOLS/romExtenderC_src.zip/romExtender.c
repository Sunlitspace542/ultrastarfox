/*romExtender rewritten in C by ChatGPT (no, seriously)*/
/*Usage example: 
romExtender "Star Fox Exploration Showcase v6.55.sfc"
or, just drag 'n' drop!*/

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s <romFile>\n", argv[0]);
        return 1;
    }

    const char* romFile = argv[1];
    FILE* currentFile = fopen(romFile, "rb");

    if (currentFile == NULL) {
        perror("Error opening file");
        return 1;
    }

    fseek(currentFile, 0, SEEK_END);
    long romFileSize = ftell(currentFile);
    fseek(currentFile, 0, SEEK_SET);

    if (romFileSize < 2097152) {
        long zeroFillAmt = 2097152 - romFileSize;

        // Allocate memory for the ROM data
        char* romData = (char*)malloc(2097152);

        if (romData == NULL) {
            fclose(currentFile);
            perror("Error allocating memory");
            return 1;
        }

        // Read the existing ROM data
        fread(romData, 1, romFileSize, currentFile);
        fclose(currentFile);

        // Fill the remaining space with zeros
        for (long i = romFileSize; i < 2097152; i++) {
            romData[i] = 0;
        }

        // Write the modified ROM data back to the file
        currentFile = fopen(romFile, "wb");
        if (currentFile == NULL) {
            perror("Error opening file for writing");
            free(romData);
            return 1;
        }

        fwrite(romData, 1, 2097152, currentFile);
        fclose(currentFile);
        free(romData);

        printf("Done adding %ld 0x00s to ROM...\n", zeroFillAmt);
    } else {
        fclose(currentFile);
        printf("Nothing to do for %s\n", romFile);
    }

    return 0;
}
